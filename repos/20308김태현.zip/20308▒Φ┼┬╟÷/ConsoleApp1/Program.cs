﻿using System;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
#region 3월22일 수업
/*
 *              //계산기
 *              string a = Console.ReadLine();
            double n1 = double.Parse(a);

            string b = Console.ReadLine();
            double n2 = double.Parse(b);

            Console.WriteLine(n1 + n2);
            Console.WriteLine(n1 - n2);
            Console.WriteLine(n1 * n2);
            Console.WriteLine(n1 / n2);
 *             Console.WriteLine(int.Parse("52"));
            Console.WriteLine(long.Parse("273"));
            Console.WriteLine(float.Parse("52.273"));
            Console.WriteLine(float.Parse("103.32"));

 *          //강제 형 변환
            int a = 0;
            double b = a;

            double c = 0;
            int d = (int)c;
 *          var numberA = 100L; 
            var unmberB = 100.0;
            var unmberC = 100.0F;
 *
 *           //변수를 선언 합니다.
 *            //int _int = 0;
            //long _long =0;
            //float _float = 0.11f;
            //double _double = 0.01;
            //char _char = '글';
            //string _string = "문자열";
            
            //출력
            //Console.WriteLine(_int.GetType());
            //Console.WriteLine(_long.GetType());
            //Console.WriteLine(_float.GetType());
            //Console.WriteLine(_double.GetType());
            //Console.WriteLine(_char.GetType());
            //Console.WriteLine(_string.GetType());

 *          //int a = 10;
            //Console.WriteLine(a++);
            //Console.WriteLine(++a);
            //Console.WriteLine(a--);
            //Console.WriteLine(--a);

 *          //string o = "Hello";
            //o = o + "World";
            //o = o+ "!";
            //Console.WriteLine(o);

 *           //int output = 0;
            //output = output + 52;
            //output = output + 273;
            //output = output + 103;
            //output += 52;
            //output += 273;
            //output += 103;
 
            //console.writeline(output);  //52+273+103
            Console.WriteLine("int: " + sizeof(int));
            Console.WriteLine("long: " + sizeof(long));
            Console.WriteLine("char: " + sizeof(char));
            Console.WriteLine("float: " + sizeof(float));
            Console.WriteLine("double: " + sizeof(double));
            Console.WriteLine("bool: " + sizeof(bool));
            int a = 3;
            Console.WriteLine(1 < a || a < 5);
       bool b1 = (1 <= 2);
       Console.WriteLine(b1);
       /*
       string s1 = "c#";
       string s2 = "Programming";
       //문자열 집합
       string s3 = s1 + " " + s2;
       //부분 문자열
       string s4 = s2.Substring(1, 3);
       //문자열 치환
       string s5 = s2.Replace("Pro", "PRO");
       //문자열 삭제
       s2.Remove(3);
       Console.WriteLine( "Hello      ".Trim());
       Console.WriteLine(s3);
       Console.WriteLine(s4);
       Console.WriteLine(s5);
       Console.WriteLine(s2.Remove(3));

       string s = "\"안녕하세요\""; //특수 코드 입력
       Console.WriteLine(s);

       Console.WriteLine("안녕하세요"[0]);  //첫번째 글자가 나온다.
       Console.WriteLine("안녕하세요"[1]);
       Console.WriteLine("안녕하세요"[2]);
       Console.WriteLine("안녕하세요"[3]);
       Console.WriteLine("안녕하세요"[4]);

       char c = 'ㄱ';
       char a = '힣';
       Console.WriteLine((int)c);
       Console.WriteLine((int)a);
       */
#endregion